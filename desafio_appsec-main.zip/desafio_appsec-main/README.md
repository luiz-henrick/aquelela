# Desafio de Segurança de Aplicações (AppSec)
## O Desafio
Este desafio segue o formato CTF, portanto, é fundamental que você não faça nenhuma modificação nos arquivos do desafio, certo?

Há mais de uma vulnerabilidade na aplicação, e a única porta disponível no Docker é a 1337. Sim, a porta 1337 é a entrada para explorar todas as vulnerabilidades.

Para obter a flag, é necessário explorar todas as vulnerabilidades em sequência.

## Write-up/Relatório
Como será avaliado o seu desafio?

Não é necessário encontrar todas as vulnerabilidades e obter a flag. O mais importante é documentar todas as vulnerabilidades identificadas, explicando como podem ser exploradas.

O formato do relatório não é estritamente definido; pode ser em PDF, Markdown ou qualquer formato que você se sinta confortável. O crucial é fornecer o máximo de detalhes possível sobre a vulnerabilidade, seus impactos e como explorá-las.