#!/bin/bash
docker build --tag=challenge_ab .
docker run -it -p 1337:80 --rm --name=challenge_ab challenge_ab