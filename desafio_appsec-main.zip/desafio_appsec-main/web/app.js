const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

const pdfGenerationURL = 'http://127.0.0.1:3002';
let isGeneratingReport = false;

const services = {
  database: 'Not Implemented',
  backend: 'Ok',
};

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('index.html');
});

app.get('/stats', (req, res) => {
  const service = req.query.service;

  if (!service || !(service in services)) {
    return res.json({
      success: false,
      message: `<strong>${service} is invalid.</strong> Please specify one of the following values: ${Object.keys(services).join(', ')}`,
    });
  }

  res.json({
    success: true,
    message: services[service],
  });
});

app.get('/report', async (req, res) => {
  if (isGeneratingReport) {
    return res.status(422).send();
  }

  isGeneratingReport = true;

  try {
    const pdfResponse = await axios.get(`${pdfGenerationURL}/generate?url=${encodeURIComponent('http://localhost/health')}`, {
      responseType: 'arraybuffer',
    });

    fs.writeFileSync('report.pdf', pdfResponse.data);

    isGeneratingReport = false;
    res.download('report.pdf');
  } catch (error) {
    isGeneratingReport = false;
    res.status(error.response?.status || 500).send(error.message);
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});