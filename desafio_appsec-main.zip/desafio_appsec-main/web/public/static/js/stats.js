const messageAlert = document.getElementById("message");
const service = document.getElementById("service");

const updateData = async () => {
fetch("/stats?service=" + service.value)
    .then((data) => data.json())
    .then((data) => {
    const { message } = data;
    
    messageAlert.innerHTML = message;
    });
};

updateData();
setTimeout(updateData, 30_000);